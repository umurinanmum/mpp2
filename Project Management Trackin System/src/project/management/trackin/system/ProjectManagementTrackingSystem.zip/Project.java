/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.management.trackin.system;

/**
 *
 * @author 986814
 */
public class Project {

    private ProjectRelease Releases;
    private String name;

    /**
     * Get the value of Releases
     *
     * @return the value of Releases
     */
    public ProjectRelease getReleases() {
        return Releases;
    }

    /**
     * Set the value of Releases
     *
     * @param Releases new value of Releases
     */
    public void setReleases(ProjectRelease Releases) {
        this.Releases = Releases;
    }

    private Backlog backlog;

    /**
     * Get the value of backlog
     *
     * @return the value of backlog
     */
    public Backlog getBacklog() {
        return backlog;
    }

    /**
     * Set the value of backlog
     *
     * @param backlog new value of backlog
     */
    public void setBacklog(Backlog backlog) {
        this.backlog = backlog;
    }

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the value of name
     *
     * @param name new value of name
     */
    public void setName(String name) {
        this.name = name;
    }
}
