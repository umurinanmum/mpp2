/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.management.trackin.system;

import java.util.Date;

/**
 *
 * @author 986814
 */
public class Report{
    
    private Sprint Sprint;

    /**
     * Get the value of Sprint
     *
     * @return the value of Sprint
     */
    public Sprint getSprint() {
        return Sprint;
    }

    /**
     * Set the value of Sprint
     *
     * @param Sprint new value of Sprint
     */
    public void setSprint(Sprint Sprint) {
        this.Sprint = Sprint;
    }

        private Date CreatedDate;

    /**
     * Get the value of CreatedDate
     *
     * @return the value of CreatedDate
     */
    public Date getCreatedDate() {
        return CreatedDate;
    }

    /**
     * Set the value of CreatedDate
     *
     * @param CreatedDate new value of CreatedDate
     */
    public void setCreatedDate(Date CreatedDate) {
        this.CreatedDate = CreatedDate;
    }

    private double AmountOfWorkCompleted;

    /**
     * Get the value of AmountOfWorkCompleted
     *
     * @return the value of AmountOfWorkCompleted
     */
    public double getAmountOfWorkCompleted() {
        return AmountOfWorkCompleted;
    }

    /**
     * Set the value of AmountOfWorkCompleted
     *
     * @param AmountOfWorkCompleted new value of AmountOfWorkCompleted
     */
    public void setAmountOfWorkCompleted(double AmountOfWorkCompleted) {
        this.AmountOfWorkCompleted = AmountOfWorkCompleted;
    }

    private double RemainingWork;

    /**
     * Get the value of RemainingWork
     *
     * @return the value of RemainingWork
     */
    public double getRemainingWork() {
        return RemainingWork;
    }

    /**
     * Set the value of RemainingWork
     *
     * @param RemainingWork new value of RemainingWork
     */
    public void setRemainingWork(double RemainingWork) {
        this.RemainingWork = RemainingWork;
    }

}
