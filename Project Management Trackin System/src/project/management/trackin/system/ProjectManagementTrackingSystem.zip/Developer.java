/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.management.trackin.system;

/**
 *
 * @author 986814
 */
public class Developer{
 
    private Feature Features;

    /**
     * Get the value of Features
     *
     * @return the value of Features
     */
    public Feature getFeatures() {
        return Features;
    }

    /**
     * Set the value of Features
     *
     * @param Features new value of Features
     */
    public void setFeatures(Feature Features) {
        this.Features = Features;
    }

        private String Name;

    /**
     * Get the value of Name
     *
     * @return the value of Name
     */
    public String getName() {
        return Name;
    }

    /**
     * Set the value of Name
     *
     * @param Name new value of Name
     */
    public void setName(String Name) {
        this.Name = Name;
    }

}


