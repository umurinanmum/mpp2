/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.management.trackin.system;

import java.util.Date;

/**
 *
 * @author 986814
 */
public class Feature{

    private Date DueDate;

    /**
     * Get the value of DueDate
     *
     * @return the value of DueDate
     */
    public Date getDueDate() {
        return DueDate;
    }

    /**
     * Set the value of DueDate
     *
     * @param DueDate new value of DueDate
     */
    public void setDueDate(Date DueDate) {
        this.DueDate = DueDate;
    }

    private double Estimation;

    /**
     * Get the value of Estimation
     *
     * @return the value of Estimation
     */
    public double getEstimation() {
        return Estimation;
    }

    /**
     * Set the value of Estimation
     *
     * @param Estimation new value of Estimation
     */
    public void setEstimation(double Estimation) {
        this.Estimation = Estimation;
    }

        private double RemainingEstimate;

    /**
     * Get the value of RemainingEstimate
     *
     * @return the value of RemainingEstimate
     */
    public double getRemainingEstimate() {
        return RemainingEstimate;
    }

    /**
     * Set the value of RemainingEstimate
     *
     * @param RemainingEstimate new value of RemainingEstimate
     */
    public void setRemainingEstimate(double RemainingEstimate) {
        this.RemainingEstimate = RemainingEstimate;
    }

    private boolean IsCompleted;

    /**
     * Get the value of IsCompleted
     *
     * @return the value of IsCompleted
     */
    public boolean isIsCompleted() {
        return IsCompleted;
    }

    /**
     * Set the value of IsCompleted
     *
     * @param IsCompleted new value of IsCompleted
     */
    public void setIsCompleted(boolean IsCompleted) {
        this.IsCompleted = IsCompleted;
    }

}


