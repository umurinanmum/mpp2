/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.management.trackin.system;

/**
 *
 * @author 986814
 */
public class ProjectRelease{
    
    private Sprint Sprints;

    /**
     * Get the value of Sprints
     *
     * @return the value of Sprints
     */
    public Sprint getSprints() {
        return Sprints;
    }

    /**
     * Set the value of Sprints
     *
     * @param Sprints new value of Sprints
     */
    public void setSprints(Sprint Sprints) {
        this.Sprints = Sprints;
    }

    private String Version;

    /**
     * Get the value of Version
     *
     * @return the value of Version
     */
    public String getVersion() {
        return Version;
    }

    /**
     * Set the value of Version
     *
     * @param Version new value of Version
     */
    public void setVersion(String Version) {
        this.Version = Version;
    }

}

