/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.management.trackin.system;

import java.util.Date;

/**
 *
 * @author 986814
 */

public class Sprint{

    private Feature Features;

    /**
     * Get the value of Features
     *
     * @return the value of Features
     */
    public Feature getFeatures() {
        return Features;
    }

    /**
     * Set the value of Features
     *
     * @param Features new value of Features
     */
    public void setFeatures(Feature Features) {
        this.Features = Features;
    }

        private int Duration;

    /**
     * Get the value of Duration
     *
     * @return the value of Duration
     */
    public int getDuration() {
        return Duration;
    }

    /**
     * Set the value of Duration
     *
     * @param Duration new value of Duration
     */
    public void setDuration(int Duration) {
        this.Duration = Duration;
    }

    private Date StartDate;

    /**
     * Get the value of StartDate
     *
     * @return the value of StartDate
     */
    public Date getStartDate() {
        return StartDate;
    }

    /**
     * Set the value of StartDate
     *
     * @param StartDate new value of StartDate
     */
    public void setStartDate(Date StartDate) {
        this.StartDate = StartDate;
    }

    private Date EndDate;

    /**
     * Get the value of EndDate
     *
     * @return the value of EndDate
     */
    public Date getEndDate() {
        return EndDate;
    }

    /**
     * Set the value of EndDate
     *
     * @param EndDate new value of EndDate
     */
    public void setEndDate(Date EndDate) {
        this.EndDate = EndDate;
    }

}
