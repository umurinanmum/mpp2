/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.management.trackin.system;

/**
 *
 * @author 986814
 */
public class ProjectManager{
    
    private Report DailyReports;

    /**
     * Get the value of DailyReports
     *
     * @return the value of DailyReports
     */
    public Report getDailyReports() {
        return DailyReports;
    }

    /**
     * Set the value of DailyReports
     *
     * @param DailyReports new value of DailyReports
     */
    public void setDailyReports(Report DailyReports) {
        this.DailyReports = DailyReports;
    }

    private String Name;

    /**
     * Get the value of Name
     *
     * @return the value of Name
     */
    public String getName() {
        return Name;
    }

    /**
     * Set the value of Name
     *
     * @param Name new value of Name
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    
    public void AssignFeaturesToDevelopers(){
    }
    
    public void AddFeaturesToRelease(){
    }
}